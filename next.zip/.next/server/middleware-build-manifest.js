globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/e4be374c26beacdd.js",
      "static/chunks/turbopack-627ba6a535a0d790.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/e4be374c26beacdd.js",
      "static/chunks/turbopack-1273f7f8be59006a.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/64efe8bc97ebb595.js",
    "static/chunks/743ef0792dd30de1.js",
    "static/chunks/30cb146bc1e6f45f.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-c6eb4893daf071cb.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];