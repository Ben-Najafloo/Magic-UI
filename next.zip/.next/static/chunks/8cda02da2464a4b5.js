__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/e4be374c26beacdd.js",
  "static/chunks/turbopack-627ba6a535a0d790.js"
])
